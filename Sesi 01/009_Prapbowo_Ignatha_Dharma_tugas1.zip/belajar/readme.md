# Sesi 1
Dalam pertemuan sesi 01, diajarkan tentang tools yang dibutuhkan dalam pembuatan website. Juga dijelaskan basic dari pembuatan program dengan HTML.

software yang diinstall :
- vscode
- xampp / laragon
- git
